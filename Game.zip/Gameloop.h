#pragma once
#include "GameObject.h"
#include <vector>
#include <map>

class Gameloop
{
public:
	static const int WINDOW_WIDTH = 800;
	static const int WINDOW_HEIGHT = 800;
	
	static void Init();
	static void Render();
	static void HandleEvents(std::vector<GameObject*> GOs, std::vector<GameObject*> scene);
	static void UpdatePhysics(std::vector<GameObject*> GOs);
	static void UpdateGraphics(std::vector<GameObject*> GOs, std::vector<GameObject*> scene);
	static void Clean();
	Gameloop() = delete;
};