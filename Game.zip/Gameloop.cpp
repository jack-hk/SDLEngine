#include "Gameloop.h"
#include "Graphics.h"
#include "SDL.h"
#include "SDL_image.h"
#include <iostream>
#include <vector>
#include "Input.h"

void Gameloop::Init()
{
	//Initialise SDL and subsystems
	if (SDL_Init(SDL_INIT_EVERYTHING) < 0)
	{
		std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;
	}
}

void Gameloop::Render()
{
	//Create window
	Graphics::window = SDL_CreateWindow("SDL Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
	if (Graphics::window == nullptr)
	{
		std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << std::endl;
	}

	Graphics::renderer = SDL_CreateRenderer(Graphics::window, -1, SDL_RENDERER_ACCELERATED);
	if (Graphics::renderer == nullptr)
	{
		std::cout << "SDL_CreateRenderer Error: " << SDL_GetError() << std::endl;
	}

	SDL_SetRenderDrawColor(Graphics::renderer, 170, 170, 220, 255);
}

void Gameloop::HandleEvents(std::vector<GameObject*> GOs, std::vector<GameObject*> scene)
{

	//Frame Refresh
	//float deltaTime = (SDL_GetTicks() - (float)(previousFrameTicks)) / 1000;
	//previousFrameTicks = SDL_GetTicks();

	while (Input::getInstance().gameIsRunning)
	{
		//Event Loop
		Input::getInstance().HandleInputs(GOs);


		UpdatePhysics(GOs);

		//Render
		SDL_RenderClear(Graphics::renderer);
		UpdateGraphics(GOs, scene);
		SDL_RenderPresent(Graphics::renderer);
	}
}

void Gameloop::UpdatePhysics(std::vector<GameObject*> GOs)
{
	for (GameObject* i : GOs)
	{
		i->Update();
		i->Move(Vector2D(-0.00003,0));
		//i->Debug();
	}

}

void Gameloop::UpdateGraphics(std::vector<GameObject*> GOs, std::vector<GameObject*> scene)
{
	for (GameObject* i : scene)
	{
		i->Draw(Graphics::renderer);
	}
	for (GameObject* i : GOs)
	{
		i->Draw(Graphics::renderer);
	}
}

void Gameloop::Clean()
{
	SDL_DestroyWindow(Graphics::window);
	SDL_DestroyRenderer(Graphics::renderer);
	SDL_Quit();
}