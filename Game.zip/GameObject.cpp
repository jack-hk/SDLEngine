#include "GameObject.h"
#include <iostream>

GameObject::GameObject(SDL_Texture* go_texture, Vector2D go_position, int go_width, int go_height)
{
	texture = go_texture;
	position.x = go_position.x;
	position.y = go_position.y;
	width = go_width;
	height = go_height;
}

void GameObject::Draw(SDL_Renderer* renderer)
{
	SDL_Rect srcRect;
	if (HasAnimation)
	{
		int currentFrameIndex = (int)(timeInAnimationState * animationSpeed) % animFrames;
		srcRect = { currentFrameIndex * animWidth, animState * animHeight, animWidth, animHeight };
	}
	SDL_Rect dstRect{ position.x, position.y, width, height };
	SDL_RenderCopy(renderer, texture, HasAnimation ? &srcRect : NULL, &dstRect);
}

void GameObject::Update()
{
	if (HasDrag)
	{
		//Y physics update
		if (velocity.y > 0)
		{
			velocity.y -= 0.02;
		}
		else if (velocity.y < 0)
		{
			velocity.y += 0.02;
		}
		//Stopping
		if (velocity.y < 0.01 && velocity.y > -0.01)
		{
			velocity.y = 0;
		}

		//X physics update
		if (velocity.x > 0)
		{
			velocity.x -= 0.02;
		}
		else if (velocity.x < 0)
		{
			velocity.x += 0.02;
		}
		//Stopping
		if (velocity.x < 0.01 && velocity.x > -0.01)
		{
			velocity.x = 0;
		}
	}

	if (HasGravity)
	{
		//Apply Gravity
		velocity.y += 0.0333;
		//Ground
		if (position.y > (700 - height))
		{
			if (velocity.y > 0)
			{
				velocity.y = 0;
			}
		}
	}

	position.x += velocity.x; //add deltatime
	position.y += velocity.y;
}

void GameObject::Clean()
{
	SDL_DestroyTexture(texture);
}

void GameObject::Move(Vector2D speed)
{
	velocity.x += speed.x;
	velocity.y += speed.y;
}

void GameObject::CameraMove(float increment)
{
	if (position.x < positiveCamRestriction && position.x > negativeCamRestriction)
	{
		position.x -= increment;
		std::cout << "Memory address: " << position.x << std::endl;
	}
	else
	{
		position.x += increment;
	}
}

void GameObject::Debug()
{
	std::cout << "Memory address: " << this << std::endl;
}

void GameObject::Clone()
{
	GameObject* clone = new GameObject(texture, position, width, height);
	clone->position.x += 100;
	clone->position.y += 100;
	clone->Debug();
}