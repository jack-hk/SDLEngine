#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <iostream>
#include "GameObject.h"
#include "Graphics.h"
#include "Gameloop.h"
#include <string>
#include <vector>

int main(int argc, char* args[])
{
	static std::vector<GameObject*> gameObjects;
	static std::vector<GameObject*> sceneObjects;
	
	Gameloop::Init();
	Gameloop::Render();

	SDL_Texture* img_tank = Graphics::LoadTexture("Assets/tank.png");
	SDL_Texture* img_hq = Graphics::LoadTexture("Assets/hq.png");
	SDL_Texture* img_citybg = Graphics::LoadTexture("Assets/citybg.png");
	SDL_Texture* img_ground = Graphics::LoadTexture("Assets/ground.png");
	SDL_Texture* color_black = Graphics::LoadTexture("Assets/black.png");
	
	GameObject background(img_citybg, Vector2D(0, 0), 800, 800);
	GameObject ground(img_ground, Vector2D(0, 650), 800, 50);
	GameObject bottom(color_black, Vector2D(0, 700), 800, 300);
	GameObject go2(img_tank, Vector2D(0, 0), 170, 128);

	go2.HasDrag = true;
	go2.HasGravity = true;

	sceneObjects.push_back(&background);
	sceneObjects.push_back(&ground);
	sceneObjects.push_back(&bottom);
	gameObjects.push_back(&go2);


	Gameloop::HandleEvents(gameObjects, sceneObjects);
	Gameloop::Clean();

	return 0;
}