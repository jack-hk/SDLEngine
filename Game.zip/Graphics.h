#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <iostream>

class Graphics
{
public:
	static SDL_Window* window;
	static SDL_Renderer* renderer;
	Graphics() = delete;

	static SDL_Texture* LoadTexture(const char* filename);
};

