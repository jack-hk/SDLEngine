#pragma once
#include <SDL_stdinc.h>
#include <SDL.h>
#include <iostream>
#include "GameObject.h"
#include <vector>

    //singleton
class Input
{
public:
    static Input& getInstance()
    {
        static Input instance;
        return instance;
    }
private:
    Input() {}
public:
    Input(Input const&) = delete;
    void operator=(Input const&) = delete;

    bool gameIsRunning = true;
    void HandleInputs(std::vector<GameObject*> GOs);
	void RightButtonDown(std::vector<GameObject*> GOs);
	void LeftButtonDown(std::vector<GameObject*> GOs);

    void NumberOneButtonDown(std::vector<GameObject*> GOs);
    void NumberTwoButtonDown(std::vector<GameObject*> GOs);
    void NumberThreeButtonDown(std::vector<GameObject*> GOs);
};