#pragma once
#include <SDL.h>
#include "Vector.h"

class GameObject
{
public:
	Vector2D position = Vector2D(0, 0);
	int width = 32;
	int height = 32;
	SDL_Texture* texture = nullptr;

	//camera
	float positiveCamRestriction = 30 * 40;
	float negativeCamRestriction = -30 * 40;
	
	//properties
	bool HasAnimation = false;
	bool HasDrag = false;
	bool HasGravity = false;
	
	//animation
	int animHeight = 32;
	int animWidth = 32;
	int animState = 0;
	int animFrames = 1;
	float timeInAnimationState = 0;
	float animationSpeed = 1;

	GameObject(SDL_Texture* go_texture, Vector2D go_position, int go_width, int go_height);
	
	void Draw(SDL_Renderer* renderer);
	void Update();
	void Clean();
	void CameraMove(float increment);
	void Move(Vector2D speed);
	
	void Clone();

	void Debug();
protected:
	Vector2D velocity = Vector2D(0, 0);
};
