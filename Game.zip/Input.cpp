#include "Input.h"
#include "Gameloop.h"
#include "GameObject.h"
#include <iostream>

void Input::HandleInputs(std::vector<GameObject*> GOs)
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			gameIsRunning = false;
			break;
		case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE)
			{
				gameIsRunning = false;
			}
			if (event.key.keysym.sym == SDLK_RIGHT)
			{
				LeftButtonDown(GOs);
			}
			if (event.key.keysym.sym == SDLK_LEFT)
			{
				RightButtonDown(GOs);
			}
			if (event.key.keysym.sym == SDLK_1)
			{
				NumberOneButtonDown(GOs);
			}
			if (event.key.keysym.sym == SDLK_2)
			{
				NumberTwoButtonDown(GOs);
			}			
			if (event.key.keysym.sym == SDLK_3)
			{
				NumberThreeButtonDown(GOs);
			}
		}
	}
}

void Input::LeftButtonDown(std::vector<GameObject*> GOs)
{
	for (GameObject* i : GOs)
	{
		i->CameraMove(30);
	}
}

void Input::RightButtonDown(std::vector<GameObject*> GOs)
{
	for (GameObject* i : GOs)
	{
		i->CameraMove(-30);
	}
}

void Input::NumberOneButtonDown(std::vector<GameObject*> GOs)
{
	std::cout << "1" << std::endl;
	for (GameObject* i : GOs)
	{
		i->Clone();
	}
}

void Input::NumberTwoButtonDown(std::vector<GameObject*> GOs)
{
	std::cout << "Number 2 pressed" << std::endl;
}

void Input::NumberThreeButtonDown(std::vector<GameObject*> GOs)
{
	std::cout << "Number 3 pressed" << std::endl;
}