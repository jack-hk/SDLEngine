#include "Vector.h"

Vector2D::Vector2D(float x, float y)
{
	this->x = x;
	this->y = y;
}